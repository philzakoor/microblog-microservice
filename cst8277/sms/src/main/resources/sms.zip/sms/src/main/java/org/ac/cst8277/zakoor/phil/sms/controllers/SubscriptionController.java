package org.ac.cst8277.zakoor.phil.sms.controllers;

import org.ac.cst8277.zakoor.phil.sms.dao.DaoHelper;
import org.ac.cst8277.zakoor.phil.sms.dao.SmsRepository;
import org.ac.cst8277.zakoor.phil.sms.dtos.Constants;
import org.ac.cst8277.zakoor.phil.sms.dtos.Subscriber;
import org.ac.cst8277.zakoor.phil.sms.dtos.Subscription;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@RestController
public class SubscriptionController {

    @Autowired
    private SmsRepository smsRepository;

    Map<String, Object> response = new HashMap<>();

    @RequestMapping(method = RequestMethod.GET, path = "/subscriptions")
    public Mono<ResponseEntity<Map<String, Object>>> getAllSubscriptions() {

        Map<UUID, Subscriber> subscriber = smsRepository.getAllSubscriptions();

        if (subscriber.size() == 0) {
            response.put(Constants.CODE, "500");
            response.put(Constants.MESSAGE, "Subscriptions have not been retrieved");
            response.put(Constants.DATA, new HashMap<>());
        } else {
            response.put(Constants.CODE, "200");
            response.put(Constants.MESSAGE, "List of Subscriptions has been requested successfully");
            response.put(Constants.DATA, subscriber);
        }
        return Mono.just(ResponseEntity.ok().header(Constants.CONTENT_TYPE, Constants.APPLICATION_JSON)
                .header(Constants.ACCEPT, Constants.APPLICATION_JSON).body(response));
    }

    @RequestMapping(method = RequestMethod.GET, path = "/subscriptions/{userId}")
    public Mono<ResponseEntity<Map<String, Object>>> getSubscriptions(@PathVariable (value = "userId", required = true) String userId) {

        Subscriber subscriber = smsRepository.getSubscriptions(UUID.fromString(userId));

        if (subscriber.getId() == null) {
            response.put(Constants.CODE, "500");
            response.put(Constants.MESSAGE, "Posts have not been retrieved");
            response.put(Constants.DATA, new HashMap<>());
        } else {
            response.put(Constants.CODE, "200");
            response.put(Constants.MESSAGE, "List of Posts has been requested successfully");
            response.put(Constants.DATA, subscriber);
        }
        return Mono.just(ResponseEntity.ok().header(Constants.CONTENT_TYPE, Constants.APPLICATION_JSON)
                .header(Constants.ACCEPT, Constants.APPLICATION_JSON).body(response));
    }

    @RequestMapping(method = RequestMethod.POST, path = "/subscriptions", consumes = Constants.APPLICATION_JSON)
    public Mono<ResponseEntity<Map<String, Object>>> subscribe(@RequestBody Subscription subscription) {

        UUID id = smsRepository.subscribe(subscription);

        if (id == null) {
            response.put(Constants.CODE, "500");
            response.put(Constants.MESSAGE, "Subscribe unsucessful");
            response.put(Constants.DATA, "");
        } else {
            response.put(Constants.CODE, "200");
            response.put(Constants.MESSAGE, "Successful Subscription");
            response.put(Constants.DATA, id);
        }
        return Mono.just(ResponseEntity.ok().header(Constants.CONTENT_TYPE, Constants.APPLICATION_JSON)
                .header(Constants.ACCEPT, Constants.APPLICATION_JSON).body(response));
    }

    @RequestMapping(method = RequestMethod.DELETE, path = "/subscriptions", consumes = Constants.APPLICATION_JSON)
    public Mono<ResponseEntity<Map<String, Object>>> unsubscribe(@RequestBody Subscription subscription) {

        int rsp = smsRepository.unsubscribe(subscription);

        if (rsp != 1) {
            response.put(Constants.CODE, "500");
            response.put(Constants.MESSAGE, "already unsubscribed");
            response.put(Constants.DATA, "");
        } else {
            response.put(Constants.CODE, "200");
            response.put(Constants.MESSAGE, "Successful unsubscription");
            response.put(Constants.DATA, subscription);
        }
        return Mono.just(ResponseEntity.ok().header(Constants.CONTENT_TYPE, Constants.APPLICATION_JSON)
                .header(Constants.ACCEPT, Constants.APPLICATION_JSON).body(response));
    }
}
