package org.ac.cst8277.zakoor.phil.sms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmsApplicationTests {

    @Test
    void contextLoads() {
    }

}
