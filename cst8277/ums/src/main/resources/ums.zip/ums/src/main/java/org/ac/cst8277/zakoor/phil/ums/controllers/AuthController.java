package org.ac.cst8277.zakoor.phil.ums.controllers;

import org.ac.cst8277.zakoor.phil.ums.dao.UmsRepository;
import org.ac.cst8277.zakoor.phil.ums.dtos.Constants;
import org.ac.cst8277.zakoor.phil.ums.dtos.Roles;
import org.ac.cst8277.zakoor.phil.ums.dtos.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@RestController
public class AuthController {

    @Autowired
    private UmsRepository umsRepository;

    Map<String, Object> response = new HashMap<>();

    @RequestMapping(method = RequestMethod.GET, path = "/auth/{token}")
    public Mono<ResponseEntity<Map<String, Object>>> auth(@PathVariable (name = "token", required = true) String token) {

        User user = umsRepository.findUserByID(UUID.fromString(token));

        if (user == null) {
            response.put(Constants.CODE, "500");
        } else {
            response.put(Constants.CODE, "200");
        }
        return Mono.just(ResponseEntity.ok().header(Constants.CONTENT_TYPE, Constants.APPLICATION_JSON)
                .header(Constants.ACCEPT, Constants.APPLICATION_JSON).body(response));
    }
}
