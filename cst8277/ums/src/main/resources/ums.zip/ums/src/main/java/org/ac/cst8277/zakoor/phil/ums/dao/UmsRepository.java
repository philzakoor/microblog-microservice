package org.ac.cst8277.zakoor.phil.ums.dao;

import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.ac.cst8277.zakoor.phil.ums.dtos.Roles;
import org.ac.cst8277.zakoor.phil.ums.dtos.User;

public interface UmsRepository {

    Map<UUID, User> findAllUsers();

    Map<String, Roles> findAllRoles();

    User findUserByID(UUID userId);

    UUID createUser(User user);

    int deleteUser(UUID userId);

    List<Roles> getUserRoles(UUID userId);
}
