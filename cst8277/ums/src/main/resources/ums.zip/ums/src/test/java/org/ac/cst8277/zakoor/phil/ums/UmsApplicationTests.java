package org.ac.cst8277.zakoor.phil.ums;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UmsApplicationTests {

    @Test
    void contextLoads() {
    }

}
